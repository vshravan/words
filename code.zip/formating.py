# -*- coding: utf-8 -*-
"""
Created on Mon Apr 18 18:36:11 2022

@author: shari
"""

def data_formating()
    with open("words.txt","r") as file:
        Words= []
        for line in file:
            if not line.startswith('#'):
                if 'err' not in line:
                    line_split=line.split()
                    out=line_split[0]+str("-")+line_split[-1]
                    Words.append(out)
    return Words

result_list=data_formating()              
outfile=open("result.txt","w")
for line in result_list:
    outfile.write(line+"\n")
outfile.close()

